SMITH FX ACADEMY — WEBSITE STARTER

Files:
- index.html: responsive black-and-gold website preview.

How to preview:
1. Extract the ZIP file.
2. Open index.html in a modern browser.

Important:
This is a front-end starter/preview. It is NOT yet a production website:
- Student login is a placeholder; no real accounts are created.
- Admin area is a demo, not protected. Do not enter real student data.
- Course prices are sample prices and can be edited in index.html.
- Payment buttons are placeholders. No M-Pesa, Visa, Mastercard or PayPal payments are processed.
- No database, secure authentication, subscriptions, email delivery or certificates are connected.
- Add a real privacy policy, terms, refund policy, business contact details and risk disclosures before launch.

To publish:
Deploy the folder to a static hosting provider or connect it to a developer-managed hosting account and domain. For real student accounts, admin controls and payments, build a secure backend and integrate approved payment providers in test mode first.
